(function() {
    return {
        url: window.location.href
    };
})();
