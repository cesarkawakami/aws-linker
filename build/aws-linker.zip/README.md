# aws-linker
Go from Elastic Beanstalk to individual components and back in one click!
